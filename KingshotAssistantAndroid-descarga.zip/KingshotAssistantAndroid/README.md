# Kingshot Assistant Android — prototipo inicial

Proyecto fuente para generar una APK de prueba. No es una aplicación terminada.

## Compilar sin computadora (compilación en la nube)

Este proyecto incluye un workflow de GitHub Actions (`.github/workflows/build-apk.yml`) que compila una APK debug en la nube.

1. En el navegador del teléfono, inicia sesión en GitHub y crea un repositorio nuevo llamado `KingshotAssistantAndroid`.
2. Descomprime este ZIP en el teléfono.
3. Sube los archivos y carpetas del proyecto al repositorio conservando la estructura (incluida la carpeta oculta `.github/workflows`). No subas el ZIP como único archivo.
4. Abre la pestaña **Actions** del repositorio y habilita Actions si GitHub lo solicita.
5. Selecciona **Build Kingshot Assistant APK** y toca **Run workflow**. También se ejecuta al subir cambios a la rama `main`.
6. Cuando termine en verde, entra en esa ejecución, baja a **Artifacts** y descarga `KingshotAssistant-debug-apk.zip` al teléfono.
7. Descomprime el artefacto y toca `app-debug.apk` para instalarlo. Android puede pedir autorización para instalar desde esa fuente.

La compilación en la nube requiere una cuenta de GitHub y conexión a Internet. La APK es de depuración y no está publicada en Play Store.

## Estado funcional actual

- Interfaz oscura básica.
- Solicitud de permiso de superposición.
- Solicitud de consentimiento oficial para captura de pantalla.
- Servicio y burbuja flotante iniciales.

## Limitaciones importantes

- **No está terminada ni verificada en un teléfono real.**
- Todavía no consume los fotogramas de MediaProjection, no hace OCR/visión y no analiza Kingshot.
- El texto de la burbuja es un marcador de posición, no una IA funcionando.
- No automatiza acciones del juego.
- Nunca introduzcas contraseñas ni credenciales de Kingshot en este prototipo.
